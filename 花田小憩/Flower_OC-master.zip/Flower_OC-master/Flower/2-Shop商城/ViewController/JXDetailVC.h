//
//  JXDetailVC.h
//  Flower
//
//  Created by maShaiLi on 16/7/15.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JXmodel.h"
@interface JXDetailVC : BaseViewController

@property (nonatomic,strong) JXmodel *model;

@end
