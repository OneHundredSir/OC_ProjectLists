//
//  WHDLoginViewController.h
//  FootLove
//
//  Created by HUN on 16/7/1.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import "WHDBaseViewController.h"

@interface WHDLoginViewController : WHDBaseViewController

@property(nonatomic,copy)void (^finishBlock)();

@end
