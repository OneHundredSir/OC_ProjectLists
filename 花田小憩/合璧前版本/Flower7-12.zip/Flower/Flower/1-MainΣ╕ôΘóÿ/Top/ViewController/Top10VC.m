//
//  Top10VC.m
//  Flower
//
//  Created by HUN on 16/7/12.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import "Top10VC.h"
#import "MainTableModel.h"
#import "MainDetailViewController.h"
#import "authorCell.h"
#import "GoodCell1.h"
#import "GoodCell2.h"

@interface Top10VC ()<UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate>
@property(nonatomic,weak)UIButton *lastSeletedBtn;

@property(nonatomic,strong)UITableView *tableView_goods;

@property(nonatomic,strong)UITableView *tableView_author;

@property(nonatomic,strong)NSMutableArray *goodsArr;

@property(nonatomic,strong)NSMutableArray *authorArr;

@property(nonatomic,strong)CALayer *buttonLayer;

@property(nonatomic,assign)BOOL isGoodTable;
//装2个tableView
@property(nonatomic,strong)UIScrollView *scrollView;

@end

@implementation Top10VC
#pragma mark - lazyLoad
-(NSMutableArray *)goodsArr
{
    if (_goodsArr == nil) {
        _goodsArr = [NSMutableArray array];
    }
    return _goodsArr;
}

-(NSMutableArray *)authorArr
{
    if (_goodsArr == nil) {
        _goodsArr = [NSMutableArray array];
    }
    return _goodsArr;
}


#pragma mark - 视图加载
-(void)viewDidLoad
{
    [super viewDidLoad];
    [self _initNavi];
    [self _initView];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

#pragma mark - 初始化页面
#pragma mark 初始化navigation按钮
-(void)_initNavi
{
    /**
     *  设置右边按钮
     */
    [self setRightBtn:@"f_search" andTitle:nil];
    self.rightBtnBlock = ^(UIButton *btn)
    {
        
    };
}


#pragma mark 初始化页面
static CGFloat maginY = 10;
-(void)_initView
{
    self.view.frame = (CGRect){0,0,k_width,k_height};
    NSArray *nameArr = @[@"专栏",@"作者"];
    NSInteger fontNumber = 13;
    CGSize nameSize = [nameArr[0] sizeWithFont:font(fontNumber) constrainedToSize:(CGSize){MAXFLOAT,MAXFLOAT}];
    
    CGFloat maginX =30;
    CGFloat tempMagin = 0 ;
    CGPoint centerP = (CGPoint){self.view.center.x,0};
    CGFloat btnW = nameSize.width + maginY;
    CGFloat btnH = nameSize.height + maginY;
    for (int i=0; i<nameArr.count; i++) {
        
        tempMagin = i?maginX:(maginX+nameSize.width)*-1;
        UIButton *btn =[ [UIButton alloc]initWithFrame:(CGRect){centerP.x+tempMagin,maginY,btnW,btnH}];
        [btn setTitle:nameArr[i] forState:UIControlStateNormal];
        btn.titleLabel.font = font(fontNumber);
        [btn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        
        [btn setTitle:nameArr[i] forState:UIControlStateSelected];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateSelected];
        btn .tag = i + 10;
        if (i==0) {
            btn.selected = YES;
            _lastSeletedBtn =btn;
            self.buttonLayer = [[CALayer alloc]init];
            self.buttonLayer.frame = (CGRect){btn.frame.origin.x,maginY+btnH,btnW,2};
            self.buttonLayer.backgroundColor = [UIColor blackColor].CGColor;
            self.isGoodTable = YES;
            [self.view.layer addSublayer:self.buttonLayer];
        }
        [btn addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:btn];
    }
    
    //设置scrollView
    CGFloat scrollViewY = maginY*2 + btnH;
    _scrollView = [[UIScrollView alloc]initWithFrame:(CGRect){0,scrollViewY,k_width,k_height-scrollViewY}];
    _scrollView.delegate = self;
    _scrollView.pagingEnabled = YES;
    [self.view addSubview:_scrollView];
    
    CGFloat tableW = _scrollView.frame.size.width;
    CGFloat tableH = _scrollView.frame.size.height;
    _scrollView.contentSize = (CGSize){2*tableW,tableH};
    //专栏tablvieView
    _tableView_goods = [[UITableView alloc]initWithFrame:(CGRect){0,0,tableW,tableH}];
    //注册CELL
    //前3个
    [_tableView_goods registerNib:[UINib nibWithNibName:goodCell1ID bundle:[NSBundle mainBundle]] forCellReuseIdentifier:goodCell1ID];
    [_tableView_goods registerNib:[UINib nibWithNibName:goodCell2ID bundle:[NSBundle mainBundle]] forCellReuseIdentifier:goodCell2ID];
    _tableView_goods.rowHeight = 60;
    [_scrollView addSubview:_tableView_goods];
    
    //作者tableView
    _tableView_author = [[UITableView alloc]initWithFrame:(CGRect){tableW,0,tableW,tableH}];
    //注册CELL
    //前3个
    [_tableView_author registerNib:[UINib nibWithNibName:authorCellID bundle:[NSBundle mainBundle]] forCellReuseIdentifier:authorCellID];
    _tableView_author.rowHeight = 60;
    [_scrollView addSubview:_tableView_author];
    
    
    
}

-(void)btnAction:(UIButton *)btn
{
    _lastSeletedBtn.selected = NO;
    btn.selected = !btn.selected;
    _lastSeletedBtn = btn;
    self.buttonLayer.frame = (CGRect){btn.frame.origin.x,maginY+btn.frame.size.height,btn.frame.size.width,2};
    if (btn.selected == YES && btn.tag == 10) {
        //主要用来切换tableView的
        self.isGoodTable = YES;
    }else
    {
         self.isGoodTable = NO;
    }
}


#pragma mark - TableView
#pragma mark delegate
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    //如果是专栏就跳转到专栏
    //如果不是就跳转到自己的页面
    if (self.isGoodTable) {
        MainDetailViewController *detailVC = [MainDetailViewController new];
        detailVC.view.frame = self.view.frame;
        detailVC.model = self.goodsArr[indexPath.row];
        [detailVC setViewTitle: detailVC.model.title];
        [self.navigationController pushViewController:detailVC animated:YES];
    }else
        nil;
    
    
}


#pragma mark datasoure
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 10;
    //如果专栏..
    if (self.isGoodTable ) {
        return self.goodsArr.count;
    }else
        return self.authorArr.count;
}

static NSString *goodCell1ID = @"GoodCell1";
static NSString *goodCell2ID = @"GoodCell2";
static NSString *authorCellID = @"authorCell";
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.isGoodTable) {
        if (indexPath.row<3) {
            GoodCell1 *cell= [tableView dequeueReusableCellWithIdentifier:goodCell1ID];
            cell.model = self.goodsArr[indexPath.row];
            return cell;
        }else
        {
            GoodCell2 *cell= [tableView dequeueReusableCellWithIdentifier:goodCell2ID];
            cell.model = self.goodsArr[indexPath.row];
            return cell;
        }
    }else
    {
        authorCell *cell = [tableView dequeueReusableCellWithIdentifier:authorCellID];
        cell.model = self.authorArr[indexPath.row];
        return cell;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 5;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 5;
}


@end
