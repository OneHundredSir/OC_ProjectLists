//
//  AheaderView.h
//  Flower
//
//  Created by maShaiLi on 16/7/15.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JXdetail.h"
#import "JFDetailModel.h"
@interface AheaderView : UIView

@property (nonatomic,strong) JXdetail *model;
@property (nonatomic,strong) JFDetailModel *JFmodel;


@end
