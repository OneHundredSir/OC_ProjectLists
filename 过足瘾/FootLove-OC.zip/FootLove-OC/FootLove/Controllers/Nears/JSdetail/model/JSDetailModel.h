//
//  JSDetailModel.h
//  FootLove
//
//  Created by HUN on 16/6/30.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import <Foundation/Foundation.h>
@class JSDetailTableModel;
@interface JSDetailModel : NSObject
//------- 头部视图图片 -------/
//视频数组
WHDOringinal(videoArr)
//图片数组
WHDOringinal(imgArr)
//关注数目
WHDOringinal(focusCount)
//喜欢数目
WHDOringinal(likeCount)
//礼物数目
WHDOringinal(giftCount)
//时间
WHDOringinal(timeDetail)
//tablemodel的数组
WHDOringinal(JSTableModelArr)

@end
