//
//  JFDetailModel.m
//  Flower
//
//  Created by maShaiLi on 16/7/19.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import "JFDetailModel.h"

@implementation JFDetailModel


+ (NSDictionary *)objectClassInArray{
    return @{@"skuList" : [skulist_my class], @"specList" : [sep_my class]};
}
@end
@implementation skulist_my

@end


@implementation sep_my

@end


@implementation sku_my

@end


