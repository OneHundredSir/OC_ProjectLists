//
//  ColumModel.m
//  Flower
//
//  Created by HUN on 16/7/15.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import "ColumModel.h"

@implementation ColumModel

@end
