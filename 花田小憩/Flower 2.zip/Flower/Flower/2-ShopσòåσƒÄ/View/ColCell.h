//
//  ColCell.h
//  Flower
//
//  Created by maShaiLi on 16/7/12.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ColCell : UICollectionViewCell

@end
