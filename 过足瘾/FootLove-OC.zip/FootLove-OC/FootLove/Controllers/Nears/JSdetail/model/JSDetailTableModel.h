//
//  JSDetailTableModel.h
//  FootLove
//
//  Created by HUN on 16/6/30.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JSDetailTableModel : NSObject
//说说
WHDOringinal(signature)
//门店
WHDOringinal(shop_name)
//工号
WHDOringinal(work_id)
//地址
WHDOringinal(shop_addr)

@end
