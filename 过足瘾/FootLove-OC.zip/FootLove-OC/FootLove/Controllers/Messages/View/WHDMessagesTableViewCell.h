//
//  WHDMessagesTableViewCell.h
//  FootLove
//
//  Created by HUN on 16/7/1.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MessageModel;
@interface WHDMessagesTableViewCell : UITableViewCell

@property(nonatomic,strong)MessageModel *model;

@end
