//
//  WHDNearsTableViewCell.h
//  FootLove
//
//  Created by HUN on 16/6/28.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import <UIKit/UIKit.h>
@class WHDDPModel;
@interface WHDNearsTableViewCell : UITableViewCell

@property(nonatomic,strong)WHDDPModel *model;
@end
