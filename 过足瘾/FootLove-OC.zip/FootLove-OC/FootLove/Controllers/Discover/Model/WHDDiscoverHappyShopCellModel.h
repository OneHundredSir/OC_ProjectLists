//
//  WHDDiscoverHappyShopCellModel.h
//  FootLove
//
//  Created by HUN on 16/6/30.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WHDDiscoverHappyShopCellModel : NSObject

@end
