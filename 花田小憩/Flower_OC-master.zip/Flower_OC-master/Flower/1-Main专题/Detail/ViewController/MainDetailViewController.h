//
//  MainDetailViewController.h
//  Flower
//
//  Created by HUN on 16/7/11.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import "BaseViewController.h"
#import "MainTableModel.h"
@interface MainDetailViewController : BaseViewController

@property(nonatomic,strong)MainTableModel *model;

@end
