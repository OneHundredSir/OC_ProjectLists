//
//  JFDetailVC.h
//  Flower
//
//  Created by maShaiLi on 16/7/19.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import "BaseViewController.h"

@interface JFDetailVC : BaseViewController

@property (nonatomic,copy) NSString *fnIdStr;


@end
