//
//  GoodCell2.h
//  Flower
//
//  Created by HUN on 16/7/12.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MainTableModel;
@interface GoodCell2 : UITableViewCell

@property(nonatomic,strong)MainTableModel *model;

@end
