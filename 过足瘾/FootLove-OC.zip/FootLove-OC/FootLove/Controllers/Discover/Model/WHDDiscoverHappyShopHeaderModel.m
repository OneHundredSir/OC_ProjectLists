//
//  WHDDiscoverHappyShopHeaderModel.m
//  FootLove
//
//  Created by HUN on 16/6/30.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import "WHDDiscoverHappyShopHeaderModel.h"

@implementation WHDDiscoverHappyShopHeaderModel

@end
