//
//  WebCommonVC.h
//  Flower
//
//  Created by HUN on 16/7/9.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import "BaseViewController.h"

@interface WebCommonVC : BaseViewController

@property(nonatomic,copy)NSString *UrlString;

@end
