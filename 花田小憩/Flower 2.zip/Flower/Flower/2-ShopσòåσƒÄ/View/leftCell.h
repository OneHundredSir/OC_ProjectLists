//
//  leftCell.h
//  Flower
//
//  Created by Administrator on 16/7/10.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface leftCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *title;

@end
