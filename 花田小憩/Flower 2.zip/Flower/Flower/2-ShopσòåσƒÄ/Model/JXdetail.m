//
//  JXdetail.m
//  Flower
//
//  Created by maShaiLi on 16/7/12.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import "JXdetail.h"

@implementation JXdetail


//+ (NSDictionary *)objectClassInArray{
//    return @{@"specList" : [Speclist class]};
//}
@end

//@implementation Speclist
//
//@end
//
//
//@implementation Sku
//
//@end


