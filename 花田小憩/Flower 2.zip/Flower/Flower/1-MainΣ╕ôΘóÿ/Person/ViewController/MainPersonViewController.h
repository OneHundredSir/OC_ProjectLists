//
//  MainPersonViewController.h
//  Flower
//
//  Created by HUN on 16/7/13.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import "BaseViewController.h"
#import "PersonModel.h"

@interface MainPersonViewController : BaseViewController
/**
 *  进来人物的属性
 */
@property(nonatomic,strong)PersonModel *personModel;



@end
