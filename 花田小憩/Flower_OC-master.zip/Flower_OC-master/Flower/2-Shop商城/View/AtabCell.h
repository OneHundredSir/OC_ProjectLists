//
//  AtabCell.h
//  Flower
//
//  Created by maShaiLi on 16/7/11.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "JXmodel.h"
@interface AtabCell : UITableViewCell

@property (nonatomic,strong) JXmodel *model;

@end
