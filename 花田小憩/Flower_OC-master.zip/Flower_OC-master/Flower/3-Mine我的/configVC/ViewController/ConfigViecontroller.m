//
//  ConfigViecontroller.m
//  Flower
//
//  Created by HUN on 16/7/15.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import "ConfigViecontroller.h"

#define jifen @"http://m.htxq.net/servlet/SysContentServlet?action=getDetail&id=e30840e6-ef01-4e97-b612-8b930bdfd8bd"
#define renzheng @"http://m.htxq.net/servlet/SysContentServlet?action=getDetail&id=48d4eac5-18e6-4d48-8695-1a42993e082e"
#define guanyu @"http://m.htxq.net/servlet/SysContentServlet?action=getDetail&id=0001c687-9393-4ad3-a6ad-5b81391c5253"
#define hezuo @"http://m.htxq.net/servlet/SysContentServlet?action=getDetail&id=e30840e6-ef01-4e97-b612-8b930bdfd8bd"

@interface ConfigViecontroller ()<UITableViewDelegate,UIGestureRecognizerDelegate>
@property (strong, nonatomic) IBOutlet UITableView *mytableView;

@property (weak, nonatomic) IBOutlet UILabel *clear_lbl;

@property (nonatomic,copy) NSString *filePath;


@end

@implementation ConfigViecontroller

- (void)viewDidLoad {
    [super viewDidLoad];
    [self panGesture];
    [self setViewTitle:@"设置"];
    self.automaticallyAdjustsScrollViewInsets = NO;

}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self caculateFileSize];
    [self setLeftBtn:@"back" andTitle:nil];
    self.tabBarController.tabBar.hidden = YES;
}

#pragma mark delegate
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSInteger section = indexPath.section;
    NSInteger row = indexPath.row;
    if (section == 0 && row == 3)//第一组
    {
        [self pushWebView:jifen AndTitle:@"积分规则"];
        
    }else if (section == 0 && row == 4)
    {
        [self pushWebView:renzheng AndTitle:@"认证规则"];
        
    }else if (section == 1 && row == 0)
    {
        [self pushWebView:guanyu AndTitle:@"关于花田小憩"];
        
    }else if (section == 1 && row == 1)
    {
        [self pushWebView:hezuo  AndTitle:@"商业合作"];
        
    }else if (section == 1 && row == 3)
    {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"itms-apps://:itunes.apple.com/cn/app/hua-tian-xiao-qi-zi-ran-zhi/id998252000?mt=8"]];
    }else if (section == 2 && row == 0)
    {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"清除缓存" message:@"真的要清除缓存吗？" preferredStyle:UIAlertControllerStyleAlert];
        [alert  addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
            [self clearCache:_filePath];
            MBProgressHUD  *hub = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
            hub.mode = MBProgressHUDModeIndeterminate;
            [hub hide:YES afterDelay:2];
            hub.labelText = @"清除缓存中...";
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                hub.labelText = @"清理完毕";
            });
            _clear_lbl.text = @"0.00M";
            


            
        }]];
        [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            
            
        }]];
        [self presentViewController:alert animated:YES completion:nil];
    }
}



#pragma mark - 手势
- (void)panGesture
{
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(panAction:)];
    pan.delegate = self;
    [self.mytableView addGestureRecognizer:pan];
}
- (void)panAction:(UIPanGestureRecognizer *)pan
{
    //判断是否为正数
    if (pan && pan.state == UIGestureRecognizerStateBegan) {
        CGPoint distance = [pan translationInView:self.mytableView];
        if (distance.x > 0) {
            [self.navigationController popViewControllerAnimated:YES];
        }
    }if (pan.state == UIGestureRecognizerStateEnded) {
    }
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    if ([otherGestureRecognizer.view isKindOfClass:[UITableView class]]) {
        return YES;
    }
    return NO;
}

#pragma mark - 网页跳转
- (void)pushWebView:(NSString *)path AndTitle:(NSString *)title
{
    WebCommonVC *vc = [[WebCommonVC alloc]init];
    [vc setViewTitle:title];
    vc.UrlString = path;
    [self.navigationController pushViewController:vc animated:YES];
}


#pragma mark 初始化函数
static  CGFloat magin = 5;
/** 设置左边的按钮 */
-(void)setLeftBtn:(NSString *)iconStr andTitle:(NSString *)titleStr
{
    UIButton *leftBtn=[[UIButton alloc]init];
    if (iconStr || titleStr) {
        UIImage *imag = [UIImage imageNamed:iconStr];
        CGSize fontSize = [titleStr sizeWithFont:font(13) constrainedToSize:(CGSize){MAXFLOAT,44}];
        [leftBtn setImage:imag forState:UIControlStateNormal];
        leftBtn.frame = CGRectMake(magin, 0, fontSize.width+magin+imag.size.width, 44);
        [leftBtn setTitle:titleStr forState:UIControlStateNormal];
        [leftBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }else if (iconStr || !titleStr)
    {
        UIImage *imag = [UIImage imageNamed:iconStr];
        leftBtn.frame = CGRectMake(magin, 0, imag.size.width+magin, 44);
        [leftBtn setImage:imag forState:UIControlStateNormal];
    }else
    {
        CGSize fontSize = [titleStr sizeWithFont:font(13) constrainedToSize:(CGSize){MAXFLOAT,44}];
        leftBtn.frame = CGRectMake(magin, 0, fontSize.width+magin, 44);
        [leftBtn setTitle:titleStr forState:UIControlStateNormal];
        [leftBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    [leftBtn addTarget:self action:@selector(leftWay:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *item =[[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem=item;
}


-(void)leftWay:(UIButton *)btn
{
    [self popVC];
}

/** 设置顶部 */
-(void)setViewTitle:(NSString *)title
{
    UILabel *titleLB = [[UILabel  alloc]initWithFrame:(CGRect){0,0,100,44}];
    titleLB.text = title;
    titleLB.textAlignment = NSTextAlignmentCenter;
    titleLB.textColor = [UIColor blackColor];
    titleLB.font=font(14);
    self.navigationItem.titleView = titleLB;
}


#pragma mark - 计算缓存
- (void)caculateFileSize
{
    //~~~~~~~~~~~~~~~~~~~~~~
    //显示缓存大小
    _filePath = [NSString stringWithFormat:@"%@/Library/Caches/",NSHomeDirectory()];
    float size = [self folderSizeAtPath:_filePath];
    self.clear_lbl.text = [NSString stringWithFormat:@"%.02fM",size];
}


-(float)folderSizeAtPath:(NSString *)path{
    NSFileManager *fileManager=[NSFileManager defaultManager];
    float folderSize;
    if ([fileManager fileExistsAtPath:path]) {
        NSArray *childerFiles=[fileManager subpathsAtPath:path];
        for (NSString *fileName in childerFiles) {
            NSString *absolutePath=[path stringByAppendingPathComponent:fileName];
            folderSize +=[self fileSizeAtPath:absolutePath];
        }
        //SDWebImage框架自身计算缓存的实现
        folderSize+=[[SDImageCache sharedImageCache] getSize]/1024.0/1024.0;
        return folderSize;
    }
    return 0;
}
#pragma mark - 缓存大小
-(float)fileSizeAtPath:(NSString *)path{
    NSFileManager *fileManager=[NSFileManager defaultManager];
    if([fileManager fileExistsAtPath:path]){
        long long size=[fileManager attributesOfItemAtPath:path error:nil].fileSize;
        return size/1024.0/1024.0;
    }
    return 0;
}


#pragma mark - 清除缓存
-(void)clearCache:(NSString *)path{
    NSFileManager *fileManager=[NSFileManager defaultManager];
    if ([fileManager fileExistsAtPath:path]) {
        NSArray *childerFiles=[fileManager subpathsAtPath:path];
        for (NSString *fileName in childerFiles) {
            //如有需要，加入条件，过滤掉不想删除的文件
            NSString *absolutePath=[path stringByAppendingPathComponent:fileName];
            [fileManager removeItemAtPath:absolutePath error:nil];
        }
    }
    [[SDImageCache sharedImageCache] cleanDisk];
}




- (IBAction)notiAction:(id)sender {
    
   
}



#pragma mark 出栈//多一个判断
-(void)popVC
{
    if (self.navigationController.viewControllers.count > 1) {
        [self.navigationController popViewControllerAnimated:YES];
    }
}
@end
