//
//  IdDetailViewController.h
//  Flower
//
//  Created by HUN on 16/7/12.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import "BaseViewController.h"

@interface IdDetailViewController : BaseViewController


@property(nonatomic,strong)NSMutableDictionary *paramas;
@end
