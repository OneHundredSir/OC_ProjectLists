//
//  WHDMessageModel.m
//  FootLove
//
//  Created by HUN on 16/7/2.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import "WHDMessageModel.h"

@implementation WHDMessageModel

@end
