//
//  IntroduceModel.h
//  Flower
//
//  Created by HUN on 16/7/15.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IntroduceModel : NSObject

@property (nonatomic, copy) NSString *contentThird;

@property (nonatomic, copy) NSString *fnId;

@property (nonatomic, copy) NSString *fnUserID;

@property (nonatomic, copy) NSString *contentSecond;

@property (nonatomic, copy) NSString *contentFirst;

@end
