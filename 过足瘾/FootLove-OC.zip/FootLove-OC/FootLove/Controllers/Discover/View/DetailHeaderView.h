//
//  DetailHeaderView.h
//  JoinTheFoot
//
//  Created by skd on 16/6/30.
//  Copyright © 2016年 lzm. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WHDDiscoverShopModel.h"
@interface DetailHeaderView : UIView

@property (nonatomic , strong) WHDDiscoverShopModel *giftModel;
@end

