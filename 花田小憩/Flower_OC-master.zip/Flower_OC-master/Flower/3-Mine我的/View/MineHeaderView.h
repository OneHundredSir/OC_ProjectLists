//
//  MineHeaderView.h
//  Flower
//
//  Created by HUN on 16/7/18.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIView+WHDTOOl.h"
@class PersonModel;
@interface MineHeaderView : UICollectionReusableView

/**
 *  传进来的personModel
 */
@property(nonatomic,strong)PersonModel *model;
@end
