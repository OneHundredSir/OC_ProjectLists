//
//  WHDGiftDetailViewController.h
//  FootLove
//
//  Created by HUN on 16/7/5.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import "WHDBaseViewController.h"

@interface WHDGiftDetailViewController : WHDBaseViewController
@property(nonatomic,strong)id gift_id;
@end
