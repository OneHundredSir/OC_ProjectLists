//
//  MineViewController.m
//  Flower
//
//  Created by HUN on 16/7/7.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import "MineViewController.h"
#import "ConfigViecontroller.h"
#import "MineHeaderView.h"
#import "PersonColumnCell.h"
#import "PersonModel.h"
#import "ColumModel.h"
#import "MainDetailViewController.h"
#import "ColumModel.h"
@interface MineViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UIGestureRecognizerDelegate>

@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property(nonatomic,strong)NSMutableArray *modelArr;

@end

@implementation MineViewController

#pragma mark lazyLoad
-(NSMutableArray *)modelArr
{
    if (_modelArr == nil) {
        _modelArr = [NSMutableArray array];
    }
    return _modelArr;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setRightBtn:@"pc_setting_40x40" andTitle:nil];
    
    __weak MineViewController *tempVC = self;
    self.rightBtnBlock = ^(UIButton *btn)
    {
        [tempVC rightBtnAction];
    };
   
    [self _initCollection];
    [self panGesture];
}


- (void) viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self isLoginSatueWith:nil];
    
    pageIndex = 0;
    [self webRequestFormodel];
    _collectionView.mj_footer = [MJRefreshAutoFooter footerWithRefreshingBlock:^{
        pageIndex ++;
        
    }];

}

#pragma mark - 右边按钮跳转
- (void)rightBtnAction
{
    ConfigViecontroller *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"ConfigViecontroller"];
    
    [self.navigationController pushViewController:vc animated:YES];
}


#pragma mark - 手势
- (void)panGesture
{
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(panAction:)];
    pan.delegate = self;
    [self.collectionView addGestureRecognizer:pan];
}
- (void)panAction:(UIPanGestureRecognizer *)pan
{
    //判断是否为负数
    if (pan && pan.state == UIGestureRecognizerStateBegan) {
        CGPoint distance = [pan translationInView:self.collectionView];
        if (distance.x < 0) {
            [self rightBtnAction];
        }
    }
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    if ([otherGestureRecognizer.view isKindOfClass:[UICollectionView class]])
    {
        return YES;
    }
    return NO;
}


#pragma mark - _initCollection
static NSString *columnCell = @"PersonColumnCell";
static NSString *MineHeadV = @"MineHeaderView";
-(void)_initCollection
{
    _collectionView.backgroundColor = [UIColor whiteColor];
    [_collectionView registerNib:[UINib nibWithNibName:columnCell bundle:nil] forCellWithReuseIdentifier:columnCell];
    [_collectionView registerNib:[UINib nibWithNibName:MineHeadV bundle:nil]  forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:MineHeadV ];
    
}

/**
 *  请求数据的网络加载
 */

//http://m.htxq.net/servlet/UserCenterServlet?action=getMySubscibeContents¤tPageIndex=0&pageSize=15&userId=c2e81886-b3d0-4dcb-86ee-1a7ece6e28ee&(null)=
#define listUrl @"http://m.htxq.net/servlet/UserCenterServlet?action=getMySubscibeContents"
static NSInteger pageIndex = 0;
-(void)webRequestFormodel
{
    
    NSMutableDictionary *paramters = [@{} mutableCopy];
    NSString *indexPage = [NSString stringWithFormat:@"%ld",(long)pageIndex];
    [paramters setObject:indexPage forKey:@"currentPageIndex"];
    [paramters setObject:@"5" forKey:@"pageSize"];
    [paramters setObject:MyUserID forKey:@"userId"];
    [WHDHttpRequest getUserListWithparamters:paramters andandCompletion:^(NSData *data, NSURLResponse *response, NSError *error) {
        if (!error) {
            NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSArray *resultArr = dic[@"result"];
            
            if (resultArr.count>0) {
                [_collectionView.mj_footer endRefreshing];
            }else
                [_collectionView.mj_footer endRefreshingWithNoMoreData];
//            NSLog(@"%@",resultArr);
            for (NSDictionary *getDic in resultArr) {
                ColumModel *model = [ColumModel mj_objectWithKeyValues:getDic];
                model.authorModel = getDic[@"author"];
                [self.modelArr addObject:model];
            }
            [_collectionView reloadData];
        }else
        {
            NSLog(@"出现错误%@",error);
        }
    }];
}

#pragma mark  - collectiondelegate
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    [collectionView deselectItemAtIndexPath:indexPath animated:YES];
        MainDetailViewController *detailVC = [MainDetailViewController new];
        detailVC.view.frame = self.view.frame;
        ColumModel *model = self.modelArr[indexPath.row];
        //        需要网络请求
        NSMutableDictionary *paramas = [@{} mutableCopy];
        [paramas setObject:model.id forKey:@"articleId"];
        [paramas setObject:MyUserID forKey:@"userId"];
        [WHDHttpRequest getArticleDetailWithparamters:paramas andandCompletion:^(NSData *data, NSURLResponse *response, NSError *error) {
            if (!error) {
                NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
//                NSLog(@"%@",dic);
                NSDictionary *resultDic = dic[@"result"];
                detailVC.model = [MainTableModel mj_objectWithKeyValues:resultDic];
                [detailVC setViewTitle: detailVC.model.title];
                [self.navigationController pushViewController:detailVC animated:YES];
            }else
            {
                NSLog(@"%@",error);
            }
        }];
}
#pragma mark datasource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.modelArr.count;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    PersonColumnCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:columnCell forIndexPath:indexPath];
    
    cell.model = self.modelArr[indexPath.row];
    return cell;
}

#pragma mark 设置头部
static UICollectionReusableView *reusableview = nil;
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath

{
    if (reusableview == nil) {
        if (kind == UICollectionElementKindSectionHeader){
            
            MineHeaderView *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:MineHeadV forIndexPath:indexPath];
            [WHDHttpRequest getUserDetailWithuserId:MyUserID andandCompletion:^(NSData *data, NSURLResponse *response, NSError *error) {
                NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
                //            NSLog(@"%@",dic);
                headerView.model = [PersonModel mj_objectWithKeyValues:dic[@"result"]];
                
                [headerView layoutIfNeeded];
            }];
            reusableview = headerView;
            
        }
    }
    return reusableview;
}
#pragma mark 控制每个CELL的的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{
    return (CGSize){k_width,k_height*0.25};
}

#pragma mark layout 
#pragma mark cell大小
static CGFloat maginX = 5;
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    CGFloat columW = (k_width-3*maginX)/2.0;
    CGFloat columH = k_height * 0.33;
    
    return (CGSize){columW,columH};
    
}


#pragma mark 实现间隔
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    
    return (UIEdgeInsets){maginX,maginX,maginX,maginX};
}


- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return maginX;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 0.01;
}

#pragma mark  - 自己构造方法
#pragma mark 不带block的提示框
-(void)alertMetionWitDetail:(NSString *)detailTitle
{
    UIAlertController *AlertVC = [UIAlertController alertControllerWithTitle:@"提示" message: detailTitle preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *OKAciton = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:nil];
    [AlertVC addAction:OKAciton];
    [self presentViewController:AlertVC animated:YES completion:nil];
}

#pragma mark 带block的提示框
-(void)alertMetionWitDetail:(NSString *)detailTitle andFinishBlock:(void(^)())block
{
    UIAlertController *AlertVC = [UIAlertController alertControllerWithTitle:@"提示" message: detailTitle preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *OKAciton = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        if (block) {
            block();
        }
    }];
    UIAlertAction *quxiaoAciton = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
    }];
    [AlertVC addAction:OKAciton];
    [AlertVC addAction:quxiaoAciton];
    [self presentViewController:AlertVC animated:YES completion:^{
        
    }];
}
@end
