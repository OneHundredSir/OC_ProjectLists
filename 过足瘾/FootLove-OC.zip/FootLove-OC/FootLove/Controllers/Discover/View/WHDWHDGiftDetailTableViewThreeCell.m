//
//  WHDWHDGiftDetailTableViewThreeCell.m
//  FootLove
//
//  Created by HUN on 16/7/5.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import "WHDWHDGiftDetailTableViewThreeCell.h"

@interface WHDWHDGiftDetailTableViewThreeCell ()
@property (weak, nonatomic) IBOutlet UILabel *title;

@end


@implementation WHDWHDGiftDetailTableViewThreeCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
