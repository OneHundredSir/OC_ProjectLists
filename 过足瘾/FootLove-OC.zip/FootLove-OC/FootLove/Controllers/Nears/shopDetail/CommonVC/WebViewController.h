//
//  WebViewController.h
//  FootLove
//
//  Created by HUN on 16/6/29.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import "WHDBaseViewController.h"

@interface WebViewController : WHDBaseViewController
@property(nonatomic,copy)NSString *urlStr;
@end
