//
//  WHDGiftDetailTableViewOneCell.h
//  FootLove
//
//  Created by HUN on 16/7/5.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WHDGiftDetailTableViewOneCell : UITableViewCell

@end
