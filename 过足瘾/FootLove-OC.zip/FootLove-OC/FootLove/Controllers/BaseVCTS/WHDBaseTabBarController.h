//
//  WHDBaseTabBarController.h
//  FootLove
//
//  Created by HUN on 16/6/27.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WHDBaseTabBarController : UITabBarController

//把手势放出来
@property(nonatomic,weak)UIPanGestureRecognizer *pan;



@end
