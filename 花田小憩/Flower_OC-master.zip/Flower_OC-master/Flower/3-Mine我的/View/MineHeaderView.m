//
//  MineHeaderView.m
//  Flower
//
//  Created by HUN on 16/7/18.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import "MineHeaderView.h"
#import "PersonModel.h"
#import <UIButton+WebCache.h>
@interface MineHeaderView()
//头像
@property (weak, nonatomic) IBOutlet UIButton *titleImg;
//人名
@property (weak, nonatomic) IBOutlet UILabel *titleLB;
//细节
@property (weak, nonatomic) IBOutlet UILabel *detailLB;
//积分
@property (weak, nonatomic) IBOutlet UILabel *scroce;
//等级
@property (weak, nonatomic) IBOutlet UILabel *levelLB;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *progresswidth;

@property(nonatomic,copy)NSString *idString;

@property (weak, nonatomic) IBOutlet UILabel *experienceLB;
@property(nonatomic,strong)NSTimer *timer;
@end

@implementation MineHeaderView
-(void)setModel:(PersonModel *)model
{
    _model = model;
    
    _idString = _model.id;
    
    //头像
    if (_model.headImg.length>0) {
        //设置背景大图
        [_titleImg sd_setImageWithURL:[NSURL URLWithString:_model.headImg] forState:UIControlStateNormal];
    }else
    {
        [_titleImg setImage:[UIImage imageNamed:@"placehodlerX"] forState:UIControlStateNormal];
    }
    _titleImg.layer.cornerRadius = _titleImg.frame.size.width/2.0;
    _titleImg.layer.borderColor = [UIColor whiteColor].CGColor;
    _titleImg.layer.borderWidth = 1;
    _titleImg.clipsToBounds = YES;
    //设置点赞颜色,看下要不要判断
    
    
    _titleLB.text = _model.userName;
    
    _detailLB.text = _model.identity.length>0?_model.identity:@"这家伙很懒，什么也没有留下";
    
    _scroce.text = [NSString stringWithFormat:@"已获取%ld积分",(long)_model.experience];
    
    _levelLB.text =[NSString stringWithFormat:@"LV.%ld",(long)_model.level];
    
    _experienceLB.text = [NSString stringWithFormat:@"%ld",(long)_model.experience];
    _progresswidth.constant = 0;//先至0，待会定时器+
    _timer = [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(timeCalculate:) userInfo:nil repeats:YES];
}

static NSInteger scorceBase = 16;
-(void)timeCalculate:(NSTimer *)time
{
    CGFloat a = _model.experience;
    CGFloat b = _model.level;
//    NSLog(@"%lf,mylf,%lf",_progresswidth.constant,(a/(scorceBase*b)*30));
    if (_progresswidth.constant<(a/(scorceBase*b)*60)) {
        _progresswidth.constant += 0.5;
//        [self layoutIfNeeded];
        
    }else
    {
        [_timer invalidate];
        _timer = nil;
    }
}
@end
