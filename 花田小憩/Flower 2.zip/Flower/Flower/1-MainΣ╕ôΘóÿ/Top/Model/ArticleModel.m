//
//  ArticleModel.m
//  Flower
//
//  Created by HUN on 16/7/12.
//  Copyright © 2016年 hundred Company. All rights reserved.
//

#import "ArticleModel.h"

@implementation ArticleModel

@end
